import java.util.Scanner;

public class question {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number:");
        int n = in.nextInt();
        boolean ans = isPrime(n);
        System.out.println("Is prime: " + ans);
        System.out.println("Output: " + !ans); // Invert the result before printing
        in.close();
    }

    static boolean isPrime(int n) {
        if (n <= 1) {
            System.out.println(n + " is not prime because it is <= 1");
            return false; // Numbers less than or equal to 1 are not prime
        }
        int c = 2;
        while (c * c <= n) {
            if (n % c == 0) {
                System.out.println(n + " is not prime because it is divisible by " + c);
                return false; // If any divisor is found, the number is not prime
            }
            c++;
        }
        System.out.println(n + " is prime because no divisors were found");
        return true; // If no divisors are found, the number is prime
    }
}
