import java.util.Scanner;

public class first {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your name:");
        String b = sc.nextLine();
        int add = num(10, b);
        System.out.println(add);
        sc.close(); // Close the scanner
    }

    static int num(int a, String b) {
        int mess = 5 + b.length();
        return mess;
    }
}
