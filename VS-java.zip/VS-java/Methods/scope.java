public class scope {
    public static void main(String[] args) {
        int a=10;
        int b=20;//cannot access the int b=20 inside the funcition ---- same a all like string
        String name="venkat";
        System.out.println(a);
        System.out.println(b);
        System.out.println("before chane ="+name);
        random();

//------------------------------------------------------------------------
        /*  {
            int a=40;
            System.out.println(a);  // cannot give the same varible in the same function
            
            ---also in all data type

            String name="vikesh";
            System.out.println(name); 
        }*/

//------------------------------------------------------------------------        

        {
            System.out.println("firesy"+a);
            a=200;// change the a value in 10 to 200
            System.out.println("Change in a="+a);
            name="vikesh";
            System.out.println(name);
                //-----------------------------------------
        // anything inside the block can again initialized outside the block 
            int c=6;
         System.out.println(c);
        }
        System.out.println("Change in a="+a);// it can change the value in the  block 
        System.out.println("Change in name="+name);
          //-----------------------------------------
        // anything inside the block can again initialized outside the block 
        int c=70;
        System.out.println(c);
//------------------------------------------------------------------------
        //scopeing in for loop
        for(int i=1; i<=4; i++)
        System.out.println(i);
       /* {
            System.out.println(i); ---also in loop aldo
        } */

//------------------------------------------------------------------------
    }
    static void random(){
        int a=500;       //cannot access the int a=20 outside the funcition
        System.out.println(a);
    }
   
}
