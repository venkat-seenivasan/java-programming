import java.util.Arrays;;
public class changevalue {
    public static void main(String[] args) {
        int[] arr={1,2,3,45,6};
        change(arr);
        System.out.println(Arrays.toString(arr));
    }
    //create fun
    static void change(int[] num){
        num[0]=33;//if you make  a change to the object via 
        //this ref variable, same object will be changed
    }
    


}
