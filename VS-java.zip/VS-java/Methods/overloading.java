public class overloading {
    public static void main(String[] args) {
        fun(47);
        fun("venkat");
    }
    // method name can same but there argument should be different otherwise its types be diff.
    static void fun(int a){
        System.out.println(a);

    }
    static void fun(String a){
        System.out.println(a);
    }
}
