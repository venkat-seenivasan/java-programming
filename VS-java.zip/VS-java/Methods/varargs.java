import java.util.Arrays;
public class varargs {
    public static void main(String[] args) {
        fun(3,4,6,7,34,6,33,67,44,36,26);
        multi(2,3,"venkat","vikesh","santhosh","pranesh");
    }
        //we can use this for number of value that we cannot know that
    static void fun(int...v){
        System.out.println(Arrays.toString(v));
    }
    static void multi(int a, int b, String ...v){
        System.out.println(+a+"...Hi..."+b);
        System.out.println(Arrays.toString(v));
    }

}
