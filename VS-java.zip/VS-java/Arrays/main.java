/*import java.util.Arrays;
import java.util.Scanner;
public class main {

    public static void main(String[] args) {



       /* int[] num;//array declareation
        num=new int[5];//array initialisation
        System.out.println(num[4]); // o/p is 0
         
        String[] abc=new String[4];
        System.out.println(abc[2]);  //o/p is "null"



        // syntax
        // datatype[] variable_name = new datatypw[size];
       int[] rols = new int[5];
       // or directly
      int[] rols2 = { 3, 5, 6, 88, 33 };
      System.out.println(rols[1]);
      System.out.println(rols2[2]); */

/*--------------------------------------------------------------- */
            //array of primitivue
          /*  Scanner in =new Scanner(System.in);
            int[] arr=new int[5];
            arr[0] = 23;
            arr[1] = 12;
            arr[2] = 36;
            arr[3] = 95;
            arr[4] = 2;
          //bb  System.out.println(arr[0]);

            //for loop intput
        //    for(int i=0;i<arr.length;i++){
        //        arr[i]=in.nextInt();
//
       //    }
       //         System.out.println(Arrays.toString(arr));



         //   for(int i=0;i<arr.length;i++){
           //     System.out.println(arr[i] + "  ");

            //}
       //     for(int num :arr){
        //        System.out.println(num+ " ");
         //   }


         //ARRAY OR OBJECT
            String[] str =new String[4];
            for(int i=0;i<str.length;i++){
                str[i]= in.next();
            }
            System.out.println(Arrays.toString(str));


    }
}
*/
class Solution {
    
  public static void main(String[]args){
     
      
  }
  public boolean isPalindrome(int x) {
      int temp=x;
      int rev=0;

      while(x>0){
          int digit=x%10;
          rev=(rev*10)+digit;
          x=x/10;
      }
      if(rev==temp){
      System.out.println(rev);
}
      
  }
}